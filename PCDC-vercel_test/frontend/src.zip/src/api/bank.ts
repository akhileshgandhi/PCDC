import api from "./axios"

export interface BankEntry {
  id: number
  title: string
  brief: string | null
  subject: string | null
  semester_number: number | null
  semesters: number[]
  difficulty: number
  difficulty_label: string
  source: "uploaded" | "ai_generated" | "case_builder"
  created_by: number | null
  creator_name: string | null
  creator_role: string | null
  linked_case_id: number | null
  linked_case_published: boolean
  has_attachment: boolean
  attachment_name: string | null
  has_full_case: boolean
  /** List only: false when this admin may not delete it (Institute Admin scope). */
  can_delete?: boolean
  /** Admin only: the case behind this entry was deleted from a Case Library. */
  case_deleted?: BankCaseDeleted | null
  created_at: string
}

export interface BankCaseDeleted {
  deleted_by_name: string | null
  deleted_by_role: string | null
  deleted_at: string
}

export interface BankEntryDetail extends BankEntry {
  status: string
  used_case_id: number | null
  snapshot: {
    description?: string
    industry?: string
    capabilities?: string[]
    outcome_statement?: string
    decision_options?: string[]
    learning_takeaways?: string[]
    sections?: Record<string, string | string[]>
    metadata?: Record<string, string>
    timing?: Record<string, number>
    instructions?: Record<string, string>
    questions?: Array<{ question_text: string; model_answer?: string; marking_scheme?: string }>
  }
}

export interface BankMeta {
  subjects: string[]
  semesters: number[]
  difficulties: Array<{ value: number; label: string }>
  creators: string[]
}

export interface BankFilters {
  q?: string
  subject?: string
  semester?: number
  difficulty?: number
  source?: string
  creator?: string
}

export interface BankPublishPayload {
  title?: string
  brief?: string
  content_text?: string
  subject?: string
  semester_number?: number
  difficulty?: number
  industry?: string
  functional_area?: string
  capabilities?: string[]
  outcome_statement?: string
  decision_options?: string[]
  learning_takeaways?: string[]
  sections?: Record<string, string | string[]>
  reading_time_minutes?: number
  answer_writing_time_minutes?: number
  questions?: Array<Record<string, unknown>>
  instructions?: Record<string, string>
  publish_now?: boolean
}

export interface BankPublishResult {
  case_id: number
  case_status: "draft" | "published"
  edited: boolean
  entry_visible_in_bank: boolean
  missing_fields: string[]
}

export async function getBankEntries(filters: BankFilters = {}) {
  const response = await api.get<{ items: BankEntry[]; total: number }>("/bank", { params: filters })
  return response.data
}

export async function getBankMeta() {
  const response = await api.get<BankMeta>("/bank/meta")
  return response.data
}

export async function getBankEntry(id: number) {
  const response = await api.get<BankEntryDetail>(`/bank/${id}`)
  return response.data
}

export async function getBankAttachment(id: number) {
  const response = await api.get<{ name: string; data: string }>(`/bank/${id}/attachment`)
  return response.data
}

export async function publishBankEntry(id: number, payload: BankPublishPayload) {
  const response = await api.post<BankPublishResult>(`/bank/${id}/publish`, payload)
  return response.data
}

export async function restoreBankEntryCase(id: number) {
  const response = await api.post<{ status: string; case_id: number; title: string }>(`/bank/${id}/restore-case`)
  return response.data
}

export async function deleteBankEntry(id: number) {
  const response = await api.delete<{ status: string }>(`/bank/${id}`)
  return response.data
}
